package com.example.meufinanceiro;
import androidx.room.*;
@Entity(tableName="transactions")
public class Transaction {
    @PrimaryKey(autoGenerate=true) public int id;
    public String description;
    public double amount;
    public String category;
    public String type; // "receita" ou "despesa"
    public String date; // yyyy-MM-dd
}
