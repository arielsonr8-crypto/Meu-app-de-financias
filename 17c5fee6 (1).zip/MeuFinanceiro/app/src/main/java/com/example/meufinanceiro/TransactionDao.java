package com.example.meufinanceiro;
import androidx.lifecycle.LiveData;
import androidx.room.*;
import java.util.List;
@Dao
public interface TransactionDao {
    @Insert void insert(Transaction t);
    @Update void update(Transaction t);
    @Delete void delete(Transaction t);
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    LiveData<List<Transaction>> getAll();
    @Query("SELECT COALESCE(SUM(CASE WHEN type='receita' THEN amount ELSE -amount END),0) FROM transactions")
    LiveData<Double> getBalance();
}
