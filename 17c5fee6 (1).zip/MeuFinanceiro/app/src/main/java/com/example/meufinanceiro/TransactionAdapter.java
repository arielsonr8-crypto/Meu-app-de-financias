package com.example.meufinanceiro;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;
public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.VH> {
    public interface OnItemClick { void onClick(Transaction t); }
    private final List<Transaction> items=new ArrayList<>();
    private final OnItemClick listener;
    public TransactionAdapter(OnItemClick l){listener=l;}
    public void setItems(List<Transaction> list){items.clear();items.addAll(list);notifyDataSetChanged();}
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p,int vt){
        View v=LayoutInflater.from(p.getContext()).inflate(R.layout.item_transaction,p,false);
        return new VH(v);
    }
    @Override public void onBindViewHolder(@NonNull VH h,int pos){
        Transaction t=items.get(pos);
        h.desc.setText(t.description);
        h.cat.setText(t.category+" • "+t.date);
        String s=(t.type.equals("receita")?"+ R$ ":"- R$ ")+String.format(java.util.Locale.US,"%.2f",t.amount);
        h.amount.setText(s);
        h.amount.setTextColor(h.amount.getResources().getColor(t.type.equals("receita")?android.R.color.holo_green_dark:android.R.color.holo_red_dark));
        h.itemView.setOnClickListener(v->listener.onClick(t));
    }
    @Override public int getItemCount(){return items.size();}
    static class VH extends RecyclerView.ViewHolder{
        TextView desc,cat,amount;
        VH(View v){super(v);desc=v.findViewById(R.id.txtDesc);cat=v.findViewById(R.id.txtCat);amount=v.findViewById(R.id.txtAmount);}
    }
}
