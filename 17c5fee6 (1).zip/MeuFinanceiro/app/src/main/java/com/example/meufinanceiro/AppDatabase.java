package com.example.meufinanceiro;
import android.content.Context;
import androidx.room.*;
@Database(entities={Transaction.class}, version=1, exportSchema=false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract TransactionDao transactionDao();
    private static AppDatabase instance;
    public static synchronized AppDatabase get(Context c){
        if(instance==null) instance=Room.databaseBuilder(c.getApplicationContext(),AppDatabase.class,"financeiro_db").build();
        return instance;
    }
}
