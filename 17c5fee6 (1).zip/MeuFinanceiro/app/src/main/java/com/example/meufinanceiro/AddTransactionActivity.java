package com.example.meufinanceiro;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddTransactionActivity extends AppCompatActivity {
    private TransactionDao dao;
    private int editId=-1;
    private EditText desc,amount;
    private Spinner category,type;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_add_transaction);
        dao=AppDatabase.get(this).transactionDao();
        desc=findViewById(R.id.editDesc);
        amount=findViewById(R.id.editAmount);
        category=findViewById(R.id.spinCategory);
        type=findViewById(R.id.spinType);
        Button save=findViewById(R.id.btnSave);
        editId=getIntent().getIntExtra("id",-1);
        save.setOnClickListener(v->save());
    }
    private void save(){
        String d=desc.getText().toString().trim();
        String a=amount.getText().toString().trim();
        if(d.isEmpty()||a.isEmpty()){Toast.makeText(this,"Preencha descrição e valor",Toast.LENGTH_SHORT).show();return;}
        Transaction t=new Transaction();
        t.id=editId;
        t.description=d;
        t.amount=Double.parseDouble(a.replace(",","."));
        t.category=category.getSelectedItem().toString();
        t.type=type.getSelectedItem().toString().toLowerCase(Locale.ROOT);
        t.date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        new Thread(()->{ if(editId==-1) dao.insert(t); else dao.update(t); }).start();
        Toast.makeText(this,"Salvo!",Toast.LENGTH_SHORT).show();
        finish();
    }
}
