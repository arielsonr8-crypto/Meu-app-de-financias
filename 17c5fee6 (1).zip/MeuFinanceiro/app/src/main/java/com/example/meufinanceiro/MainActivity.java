package com.example.meufinanceiro;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TransactionDao dao;
    private TransactionAdapter adapter;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        dao=AppDatabase.get(this).transactionDao();
        adapter=new TransactionAdapter(t->showOptions(t));
        RecyclerView rv=findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);
        TextView balance=findViewById(R.id.txtBalance);
        dao.getBalance().observe(this,v->balance.setText(String.format(Locale.US,"Saldo: R$ %.2f",v==null?0:v)));
        dao.getAll().observe(this,adapter::setItems);
        FloatingActionButton fab=findViewById(R.id.fab);
        fab.setOnClickListener(v->startActivity(new Intent(this,AddTransactionActivity.class)));
    }
    private void showOptions(Transaction t){
        new AlertDialog.Builder(this)
            .setTitle(t.description)
            .setItems(new String[]{"Editar","Excluir"},(d,i)->{
                if(i==0){
                    Intent it=new Intent(this,AddTransactionActivity.class);
                    it.putExtra("id",t.id);startActivity(it);
                } else {
                    new Thread(()->dao.delete(t)).start();
                }
            }).show();
    }
}
